/** Automatically generated file. DO NOT MODIFY */
package com.athapong.arcodeapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}